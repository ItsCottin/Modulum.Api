﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modulum.Application.Requests.Dynamic
{
    public class DynamicForIdRequest
    {
        public int IdTable { get; set; }
        public int IdRegistro { get; set; }
    }
}
