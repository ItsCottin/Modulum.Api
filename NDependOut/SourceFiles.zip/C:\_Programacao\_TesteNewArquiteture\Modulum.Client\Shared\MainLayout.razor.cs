﻿using Microsoft.AspNetCore.Components;
using MudBlazor;
using static MudBlazor.CategoryTypes;
using System;

namespace modulum.Client
{
    public partial class MainLayout
    {
        
    }
}
