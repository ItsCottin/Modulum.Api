﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modulum.Application.Responses.Dynamic
{
    public class RegistrosRelacionamentosResponse
    {
        public int IdRegistro { get; set; }
        public string? ValorExebicao { get; set; }
    }
}
