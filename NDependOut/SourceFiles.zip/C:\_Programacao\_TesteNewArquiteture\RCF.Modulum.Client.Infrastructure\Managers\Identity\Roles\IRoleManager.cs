﻿using modulum.Application.Requests.Identity;
using modulum.Application.Responses.Identity;
using modulum.Shared.Wrapper;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace modulum.Client.Infrastructure.Managers.Identity.Roles
{
    public interface IRoleManager : IManager
    {
        //Task<IResult<List<RoleResponse>>> GetRolesAsync();
        //
        //Task<IResult<string>> SaveAsync(RoleRequest role);
        //
        //Task<IResult<string>> DeleteAsync(string id);
        //
        //Task<IResult<PermissionResponse>> GetPermissionsAsync(string roleId);
        //
        //Task<IResult<string>> UpdatePermissionsAsync(PermissionRequest request);
    }
}