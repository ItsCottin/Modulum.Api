﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace modulum.Application.Requests.Dynamic
{
    public class MenuRequest
    {
        public string NomeTela { get; set; }
        public int Id { get; set; }
    }
}
