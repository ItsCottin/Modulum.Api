﻿namespace modulum.Shared.Constants.Role
{
    public static class RoleConstants
    {
        public const string BasicRole = "Basic";
    }
}