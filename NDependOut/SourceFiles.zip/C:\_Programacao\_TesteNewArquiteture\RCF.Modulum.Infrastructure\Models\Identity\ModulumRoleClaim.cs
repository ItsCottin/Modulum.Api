﻿using System;
using modulum.Domain.Contracts;
using Microsoft.AspNetCore.Identity;

namespace modulum.Infrastructure.Models.Identity
{
    public class ModulumRoleClaim : IdentityRoleClaim<int>
    {
    }
}