﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCF.Modulum.Infrastructure.Models.Identity
{
    public class ModulumUserRole : IdentityUserRole<int>
    {
    }
}
