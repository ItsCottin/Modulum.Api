﻿using AutoMapper;
using modulum.Application.Requests.Identity;
using modulum.Application.Responses.Identity;

namespace modulum.Client.Infrastructure.Mappings
{
    public class RoleProfile : Profile
    {
        public RoleProfile()
        {

        }
    }
}