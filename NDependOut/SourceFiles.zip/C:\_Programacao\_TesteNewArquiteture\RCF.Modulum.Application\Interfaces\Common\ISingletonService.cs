﻿namespace modulum.Application.Interfaces.Common
{
    public interface ISingletonService
    {
    }
}