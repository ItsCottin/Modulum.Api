﻿namespace modulum.Application.Interfaces.Common
{
    public interface IScopedService
    {
    }
}