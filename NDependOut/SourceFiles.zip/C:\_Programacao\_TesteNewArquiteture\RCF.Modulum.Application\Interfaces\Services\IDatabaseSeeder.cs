﻿namespace modulum.Application.Interfaces.Services
{
    public interface IDatabaseSeeder
    {
        void Initialize();
    }
}