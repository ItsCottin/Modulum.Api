﻿using System;
using System.Collections.Generic;
using modulum.Domain.Contracts;
using Microsoft.AspNetCore.Identity;

namespace modulum.Infrastructure.Models.Identity
{
    public class ModulumRole : IdentityRole<int>
    {
        
    }
}