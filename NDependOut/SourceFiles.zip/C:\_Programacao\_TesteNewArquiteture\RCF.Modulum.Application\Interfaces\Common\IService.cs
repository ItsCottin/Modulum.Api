﻿using modulum.Application.Requests.Identity;
using modulum.Shared.Wrapper;

namespace modulum.Application.Interfaces.Common
{
    public interface IService
    {
        //Task<IResult> RegisterAsync(RegisterRequest request, string origin);
    }
}