﻿namespace modulum.Client.Infrastructure.Managers
{
    public interface IManager
    {
    }
}