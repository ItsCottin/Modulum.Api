﻿namespace modulum.Infrastructure.Shared.Services
{
    internal class SendGridMailService
    {
    }
}